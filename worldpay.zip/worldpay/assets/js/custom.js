$(document).ready(function() {
  // left Nav toggle
  $(".left-nav-toggle").click(function() {
    $(".worldpay-content").toggleClass("left-sidebar-close");
  });

  // right Nav toggle
  $(".filers-toggle").click(function() {
    $(".payment-grid").toggleClass("right-sidebar-close");
  });

  // right Nav close toggle
  $(".close-filers-toggle").click(function() {
    $(".payment-grid").toggleClass("right-sidebar-close");
  });

  // overlay close toggle
  $(".grid-overlay").click(function() {
    $(".payment-grid").toggleClass("right-sidebar-close");
  });
});
